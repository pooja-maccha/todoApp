import { useState } from "react";
import ToDoItem from "./ToDoItem";
import styles from "./ToDoItem.module.css";
import style from "./Form.module.css";

export default function ToDoList({ todoList, setTodoList }) {
  return (
    <div className={styles.lists}>
      {todoList.map((item) => (
        <ToDoItem
          key={item.name}
          item={item}
          todoList={todoList}
          setTodoList={setTodoList}
        ></ToDoItem>
      ))}
    </div>
  );
}
