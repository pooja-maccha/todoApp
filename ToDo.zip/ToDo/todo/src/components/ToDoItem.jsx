import style from "./ToDoItem.module.css";
export default function ToDoItem({ item, todoList, setTodoList }) {
  function deleteItem(item) {
    console.log("deleted ", item);
    setTodoList(todoList.filter((todo) => todo !== item));
  }

  return (
    <div className={style.itemContainer}>
      <div key={item.name} className={style.item}>
        {item.name}
        <span>
          <button className={style.delete} onClick={() => deleteItem(item)}>
            X
          </button>
        </span>
        <hr />
      </div>
    </div>
  );
}
