import { useState } from "react";
import Header from "./components/Header";
import ToDo from "./components/ToDo";
import style from "./App.module.css";
function App() {
  return (
    <div className={style.App}>
      <Header />
      <ToDo />
    </div>
  );
}
export default App;
