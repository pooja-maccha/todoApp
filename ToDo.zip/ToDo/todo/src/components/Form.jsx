import { useState } from "react";
import style from "./Form.module.css";
export default function Form({ todoList, setTodoList }) {
  const [todo, setTodo] = useState({ name: "", status: false });
  function onsubmit(e) {
    e.preventDefault();
    setTodoList([...todoList, todo]);
    // console.log(todoList);
    setTodo({ name: "", status: false });
  }
  return (
    <div className={style.form}>
      <div className={style.inputContainer}>
        <input
          className={style.inputField}
          onChange={(e) => {
            setTodo({ name: e.target.value, status: false });
          }}
          value={todo.name}
          placeholder="Enter your task"
        ></input>
        <button className={style.submit} onClick={(e) => onsubmit(e)}>
          Submit
        </button>
        {/* {console.log(todoList)} */}
      </div>
    </div>
  );
}
